export class CreateNewsDto {}
