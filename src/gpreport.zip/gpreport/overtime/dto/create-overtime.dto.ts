export class CreateOvertimeDto {}
